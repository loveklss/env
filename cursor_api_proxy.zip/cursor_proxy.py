"""
Cursor Local Proxy for api.enflame.cn

Intercepts Cursor's /v1/models validation probe and forwards
actual requests to the upstream gateway with streaming support.

Usage:
    python cursor_proxy.py

Cursor Settings:
    - OpenAI API Key: dummy
    - Override OpenAI Base URL: http://127.0.0.1:4010/v1
    - Add models with "cus-" prefix (e.g. cus-claude-sonnet-4-6)
"""

import json
import http.server
import http.client
import ssl
import sys
import time
import threading
from http.server import ThreadingHTTPServer
from urllib.parse import urlparse

# ============================================================
# Configuration - EDIT HERE
# ============================================================
UPSTREAM_URL = "https://api.enflame.cn/v1"
API_KEY = "sk-BrEmfCKs3JXBWmWzWm67xsKLvuDHk82mIkkQfIPvrisiXQgp"  # Replace with your api.enflame.cn token
PREFIX = "qhu-"
LISTEN_HOST = "127.0.0.1"
LISTEN_PORT = 4010
CONN_IDLE_TIMEOUT = 60

# Upstream model names (without prefix)
MODELS = [
    # GPT
    "gpt-4o",
    "gpt-4o-mini",
    "gpt-5.4",
    "gpt-5.5",
    "gpt-5.4-medium",   # reasoning_effort=medium
    "gpt-5.4-high",     # reasoning_effort=high
    "gpt-5.4-pro",
    "gpt-5.3-codex",
    "gpt-5.2-codex",
    "gpt-image-1.5",
    "gpt-audio-1.5",
    "gpt-realtime",
    # DeepSeek
    "deepseek-chat",
    "deepseek-reasoner",
    "deepseek-v4-flash",
    "deepseek-v4-pro",
    # Gemini
    "gemini-2.5-pro",
    "gemini-3-flash-preview",
    "gemini-3.1-flash-lite",
    "gemini-3.1-pro-preview",
    "gemini-3.5-flash",
    # GLM / Kimi / MiniMax / Hunyuan
    "glm-5.1",
    "glm-5.2",          # no thinking (default)
    "glm-5.2-thinking", # thinking enabled
    "kimi-k2.5",
    "kimi-k2.6",
    "minimax-m2.7",
    "mimo-v2.5",
    "hunyuan-embedding",
    "hy3-preview",
    # Qwen
    "qwen3.5-plus",
    "qwen3.7-plus",
    "qwen3.7-max",
    # Grok
    "grok-4-20-reasoning",
    # Embedding
    "text-embedding-3-large",
]

# Model-specific parameter overrides applied before forwarding upstream.
# Key: real model name (after prefix stripped).
# Value: dict merged into request body.
MODEL_PARAMS = {
    "glm-5.2":          {"reasoning_effort": "none"},
    "glm-5.2-thinking": {"reasoning_effort": None, "_real_model": "glm-5.2"},
    "gpt-5.4":          {"_real_model": "gpt-5.4"},
    "gpt-5.4-medium":   {"reasoning_effort": "medium", "_real_model": "gpt-5.4"},
    "gpt-5.4-high":     {"reasoning_effort": "high", "_real_model": "gpt-5.4"},
}

# Models exposed to Cursor (auto-generated with prefix)
FAKE_MODELS = [f"{PREFIX}{m}" for m in MODELS]
# ============================================================

_parsed = urlparse(UPSTREAM_URL)
UPSTREAM_HOST = _parsed.hostname
UPSTREAM_PORT = _parsed.port or (443 if _parsed.scheme == "https" else 80)
UPSTREAM_SCHEME = _parsed.scheme
UPSTREAM_BASE_PATH = _parsed.path.rstrip("/")

SSL_CTX = ssl.create_default_context() if UPSTREAM_SCHEME == "https" else None

_MODELS_PAYLOAD = json.dumps({
    "object": "list",
    "data": [
        {"id": m, "object": "model", "owned_by": "enflame"}
        for m in FAKE_MODELS
    ],
}).encode()


_thread_local = threading.local()


def _new_upstream_conn():
    if UPSTREAM_SCHEME == "https":
        return http.client.HTTPSConnection(
            UPSTREAM_HOST, UPSTREAM_PORT, context=SSL_CTX, timeout=120
        )
    return http.client.HTTPConnection(
        UPSTREAM_HOST, UPSTREAM_PORT, timeout=120
    )


def _get_upstream_conn():
    now = time.monotonic()
    conn = getattr(_thread_local, "conn", None)
    last_used = getattr(_thread_local, "last_used", 0.0)
    is_new = False
    if conn is not None:
        if now - last_used > CONN_IDLE_TIMEOUT:
            try:
                conn.close()
            except Exception:
                pass
            conn = None
        elif getattr(conn, "sock", None) is None:
            conn = None
    if conn is None:
        conn = _new_upstream_conn()
        _thread_local.conn = conn
        is_new = True
    _thread_local.last_used = now
    return conn, is_new


def _touch_upstream_conn():
    _thread_local.last_used = time.monotonic()


def _discard_upstream_conn():
    conn = getattr(_thread_local, "conn", None)
    if conn is not None:
        try:
            conn.close()
        except Exception:
            pass
        _thread_local.conn = None


def _drain_response(resp):
    try:
        while resp.read(16384):
            pass
    except Exception:
        pass


def _filter_chat_tools(data):
    """Keep only function tools supported by upstream Chat Completions API."""
    tools = data.get("tools")
    if not tools:
        return
    filtered = []
    for tool in tools:
        if tool.get("type") != "function":
            continue
        fn = tool.get("function")
        if isinstance(fn, dict) and fn.get("name"):
            filtered.append(tool)
    if filtered:
        data["tools"] = filtered
    else:
        data.pop("tools", None)
        data.pop("tool_choice", None)


def _apply_model_overrides(data):
    """Apply virtual model mapping and return the virtual model name."""
    model = data.get("model", "")
    if model.startswith(PREFIX):
        data["model"] = model[len(PREFIX):]
        model = data["model"]
    virtual = model
    overrides = MODEL_PARAMS.get(virtual)
    if overrides:
        real_model = overrides.get("_real_model")
        if real_model:
            data["model"] = real_model
        for k, v in overrides.items():
            if k in ("_real_model", "reasoning_effort"):
                continue
            if v is None:
                data.pop(k, None)
            else:
                data[k] = v
    return virtual


def _configured_reasoning_effort(virtual_model):
    overrides = MODEL_PARAMS.get(virtual_model, {})
    if "reasoning_effort" in overrides:
        return overrides["reasoning_effort"]
    if virtual_model == "gpt-5.4":
        return None
    return "__unset__"


def _finalize_reasoning_effort(data, virtual_model, is_responses):
    """Apply reasoning config last; format depends on upstream API path."""
    cursor_effort = None
    reasoning = data.pop("reasoning", None)
    if isinstance(reasoning, dict):
        cursor_effort = reasoning.get("effort")

    configured = _configured_reasoning_effort(virtual_model)
    if configured == "__unset__":
        effort = cursor_effort
    else:
        effort = configured

    data.pop("reasoning_effort", None)
    data.pop("reasoning", None)

    if effort is None or effort == "none":
        return

    if is_responses:
        data["reasoning"] = {"effort": effort}
    else:
        data["reasoning_effort"] = effort


class ProxyHandler(http.server.BaseHTTPRequestHandler):

    protocol_version = "HTTP/1.1"

    # -- /v1/models interception -----------------------------------

    def _handle_models(self):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(_MODELS_PAYLOAD)))
        self.end_headers()
        self.wfile.write(_MODELS_PAYLOAD)

    # -- Generic proxy ---------------------------------------------

    def _proxy(self, method):
        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len) if content_len > 0 else None

        is_stream = False
        data = {}
        virtual_model = "?"
        raw_model = "?"
        is_responses = "/responses" in self.path
        if body:
            try:
                data = json.loads(body)
                raw_model = data.get("model", "?")
                virtual_model = _apply_model_overrides(data)
                _filter_chat_tools(data)
                _finalize_reasoning_effort(data, virtual_model, is_responses)
                is_stream = data.get("stream", False)
                body = json.dumps(data).encode()
            except (json.JSONDecodeError, KeyError):
                pass

        path = self.path
        if path.startswith("/v1"):
            path = path[3:]
        upstream_path = UPSTREAM_BASE_PATH + path

        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": self.headers.get("Content-Type", "application/json"),
            "Accept": self.headers.get("Accept", "*/*"),
            "Accept-Encoding": "identity",
            "Connection": "keep-alive",
        }
        if body:
            headers["Content-Length"] = str(len(body))

        headers_sent = False
        last_error = None
        for attempt in range(2):
            conn_label = "retry"
            try:
                conn, is_new = _get_upstream_conn()
                if attempt == 0:
                    conn_label = "new" if is_new else "reuse"
                conn.request(method, upstream_path, body=body, headers=headers)
                resp = conn.getresponse()
                _model = data.get("model", "?") if body else "?"
                if is_responses:
                    _effort = (data.get("reasoning") or {}).get("effort", "-")
                else:
                    _effort = data.get("reasoning_effort", "-")
                _api = "responses" if is_responses else "chat"
                with self._log_lock:
                    print(
                        f"  -> upstream {resp.status} api={_api} raw={raw_model} "
                        f"virtual={virtual_model} model={_model} "
                        f"effort={_effort} conn={conn_label}"
                    )

                self.send_response(resp.status)
                content_type = resp.getheader("Content-Type", "application/json")
                self.send_header("Content-Type", content_type)

                if is_stream and "text/event-stream" in content_type:
                    self.send_header("Transfer-Encoding", "chunked")
                    self.send_header("Cache-Control", "no-cache")
                    self.send_header("Connection", "keep-alive")
                    self.end_headers()
                    headers_sent = True
                    self._stream_response(resp)
                else:
                    resp_body = resp.read()
                    self.send_header("Content-Length", str(len(resp_body)))
                    self.end_headers()
                    headers_sent = True
                    self.wfile.write(resp_body)

                if resp.getheader("Connection", "").lower() == "close":
                    _discard_upstream_conn()
                else:
                    _touch_upstream_conn()
                return
            except Exception as e:
                last_error = e
                _discard_upstream_conn()
                if headers_sent:
                    break
                if attempt == 0:
                    continue
                break

        if last_error is not None:
            with self._log_lock:
                print(f"  -> proxy error: {last_error}")
            if not headers_sent:
                try:
                    error_msg = json.dumps({"error": str(last_error)}).encode()
                    self.send_response(502)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(error_msg)))
                    self.end_headers()
                    self.wfile.write(error_msg)
                except Exception:
                    pass

    def _stream_response(self, resp):
        """Forward SSE stream using HTTP/1.1 chunked transfer encoding."""
        try:
            while True:
                chunk = resp.read(16384)
                if not chunk:
                    break
                hex_len = format(len(chunk), "x")
                self.wfile.write(f"{hex_len}\r\n".encode())
                self.wfile.write(chunk)
                self.wfile.write(b"\r\n")
                self.wfile.flush()
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            _drain_response(resp)
            _discard_upstream_conn()

    # -- HTTP method dispatchers -----------------------------------

    def do_GET(self):
        if self.path in ("/v1/models", "/models"):
            self._handle_models()
        else:
            self._proxy("GET")

    def do_POST(self):
        self._proxy("POST")

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Content-Length", "0")
        self.end_headers()

    # -- Logging ---------------------------------------------------

    _log_lock = threading.Lock()

    def log_message(self, fmt, *args):
        ts = time.strftime("%H:%M:%S")
        with self._log_lock:
            print(f"[{ts}] {self.client_address[0]} {args[0]}")


def main():
    if API_KEY == "sk-xxxxxx":
        print("ERROR: Please set your API_KEY in the script before running.")
        print("       Open cursor_proxy.py and replace sk-xxxxxx with your token.")
        sys.exit(1)

    server = ThreadingHTTPServer((LISTEN_HOST, LISTEN_PORT), ProxyHandler)
    server.daemon_threads = True
    print("=" * 56)
    print("  Cursor Proxy for api.enflame.cn")
    print("=" * 56)
    print(f"  Listen  : http://{LISTEN_HOST}:{LISTEN_PORT}")
    print(f"  Upstream: {UPSTREAM_URL}")
    print(f"  Prefix  : {PREFIX}")
    print(f"  Models  : {len(FAKE_MODELS)}")
    print("=" * 56)
    print()
    print("Press Ctrl+C to stop.")
    print()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nProxy stopped.")
        server.server_close()


if __name__ == "__main__":
    main()
