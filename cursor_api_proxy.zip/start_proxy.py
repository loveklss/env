"""
One-click launcher: local proxy + localtunnel.

Usage:
    python start_proxy.py
    Or double-click start_cursor_with_proxy.bat

Displays the public URL for Cursor Settings.
"""

import subprocess
import threading
import sys
import os
import time
import re

PROXY_SCRIPT = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "cursor_proxy.py"
)
PROXY_PORT = 4010


def kill_port(port):
    """Kill processes occupying the given port (Windows only)."""
    try:
        out = subprocess.check_output(
            f'netstat -ano | findstr "LISTENING" | findstr ":{port}"',
            shell=True, stderr=subprocess.DEVNULL
        ).decode(errors="replace")
        pids = set()
        for line in out.strip().splitlines():
            parts = line.split()
            if parts:
                pids.add(parts[-1])
        for pid in pids:
            subprocess.call(
                f"taskkill /PID {pid} /F",
                shell=True, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
        if pids:
            print(f"  [cleanup] Killed {len(pids)} process(es) on port {port}")
            time.sleep(1)
    except subprocess.CalledProcessError:
        pass


def run_proxy():
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    return subprocess.Popen(
        [sys.executable, PROXY_SCRIPT],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def pipe_output(proc, prefix):
    try:
        for raw in iter(proc.stdout.readline, b""):
            line = raw.decode(errors="replace").rstrip()
            if line:
                print(f"  [{prefix}] {line}")
    except (OSError, ValueError):
        pass


def wait_proxy_ready(timeout=10):
    import urllib.request
    url = f"http://127.0.0.1:{PROXY_PORT}/v1/models"
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(url, timeout=3)
            return True
        except Exception:
            time.sleep(0.5)
    return False


def start_tunnel():
    proc = subprocess.Popen(
        ["npx", "localtunnel", "--port", str(PROXY_PORT)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        shell=True,
    )
    url = None
    deadline = time.time() + 60
    while time.time() < deadline:
        raw = proc.stdout.readline()
        if not raw:
            break
        line = raw.decode(errors="replace").strip()
        if line:
            print(f"  [tunnel] {line}")
        m = re.search(r"(https://[^\s]+\.loca\.lt)", line)
        if m:
            url = m.group(1)
            break
    return proc, url


def get_proxy_config():
    """Import PREFIX and FAKE_MODELS from cursor_proxy.py."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("cursor_proxy", PROXY_SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.PREFIX, mod.FAKE_MODELS


def print_banner(tunnel_url):
    base_url = tunnel_url.rstrip("/") + "/v1"
    try:
        prefix, models = get_proxy_config()
        example = models[0] if models else f"{prefix}glm-5.2"
    except Exception:
        example = "check cursor_proxy.py"
    print()
    print("=" * 60)
    print("  READY!")
    print("=" * 60)
    print()
    print("  Copy this to Cursor Settings -> Models:")
    print()
    print(f"    OpenAI API Key     : dummy")
    print(f"    Override Base URL  : {base_url}")
    print(f"    Add model          : {example}")
    print()
    print("  Press Ctrl+C to stop.")
    print("=" * 60)
    print()


def main():
    print()
    print("=" * 60)
    print("  Cursor API Proxy + Tunnel")
    print("=" * 60)
    print()

    print("[1/2] Starting proxy...")
    kill_port(PROXY_PORT)
    proxy_proc = run_proxy()
    threading.Thread(
        target=pipe_output, args=(proxy_proc, "proxy"), daemon=True
    ).start()

    if not wait_proxy_ready():
        print("\n  [ERROR] Proxy failed to start.")
        proxy_proc.kill()
        sys.exit(1)
    print("  [OK] Proxy on http://127.0.0.1:4010")
    print()

    print("[2/2] Starting tunnel...")
    tunnel_proc, tunnel_url = start_tunnel()
    if not tunnel_url:
        print("  [ERROR] Tunnel failed. Retrying...")
        if tunnel_proc.poll() is None:
            tunnel_proc.kill()
        time.sleep(2)
        tunnel_proc, tunnel_url = start_tunnel()

    if not tunnel_url:
        print("  [ERROR] Tunnel failed twice. Exiting.")
        proxy_proc.kill()
        sys.exit(1)

    threading.Thread(
        target=pipe_output, args=(tunnel_proc, "tunnel"), daemon=True
    ).start()

    print_banner(tunnel_url)

    try:
        while True:
            if proxy_proc.poll() is not None:
                print("  [WARN] Proxy exited, restarting...")
                proxy_proc = run_proxy()
                threading.Thread(
                    target=pipe_output,
                    args=(proxy_proc, "proxy"),
                    daemon=True,
                ).start()
                wait_proxy_ready()
                print("  [OK] Proxy restarted.")

            if tunnel_proc.poll() is not None:
                print("  [WARN] Tunnel exited, restarting...")
                tunnel_proc, tunnel_url = start_tunnel()
                if tunnel_url:
                    threading.Thread(
                        target=pipe_output,
                        args=(tunnel_proc, "tunnel"),
                        daemon=True,
                    ).start()
                    print_banner(tunnel_url)
                else:
                    print("  [ERROR] Tunnel restart failed.")

            time.sleep(3)
    except KeyboardInterrupt:
        print("\n\nShutting down...")
        proxy_proc.kill()
        tunnel_proc.kill()
        print("Stopped.")


if __name__ == "__main__":
    main()
