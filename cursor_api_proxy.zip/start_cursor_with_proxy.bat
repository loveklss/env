@echo off
chcp 65001 >nul
title Cursor API Proxy
cd /d "%~dp0"
python start_proxy.py
pause
